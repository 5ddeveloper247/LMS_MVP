<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InstructorPersonalInfo extends Model
{
    use HasFactory;

    protected $table = 'instructors_personal_info';
}
