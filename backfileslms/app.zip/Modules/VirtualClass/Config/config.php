<?php

return [
    'name' => 'VirtualClass'
];
