<?php



namespace Modules\Payment\Http\Controllers;

use App\Models\User;

use Illuminate\Http\Request;

use App\Http\Controllers\Controller;

use Brian2694\Toastr\Facades\Toastr;

use Illuminate\Support\Facades\Auth;

use Modules\Setting\Model\GeneralSetting;

use Modules\CourseSetting\Entities\Course;

use Modules\PaymentMethodSetting\Entities\PaymentMethod;

class PaymentPlanController extends Controller

{


}

