<?php

return [
    'name' => 'Instamojo'
];
